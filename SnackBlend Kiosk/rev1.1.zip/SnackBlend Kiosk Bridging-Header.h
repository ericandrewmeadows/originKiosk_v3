//
//  SnackBlend Kiosk Bridging-Header.h
//  SnackBlend Kiosk
//
//  Created by Eric Meadows on 3/8/17.
//  Copyright © 2017 Calmlee. All rights reserved.
//

#import "OpenCVWrapper.h"
#ifndef SnackBlend_Kiosk_Bridging_Header_h
#define SnackBlend_Kiosk_Bridging_Header_h


#endif /* SnackBlend_Kiosk_Bridging_Header_h */
