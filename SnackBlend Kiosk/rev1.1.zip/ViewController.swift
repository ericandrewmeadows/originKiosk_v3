//
//  ViewController.swift
//  SnackBlend Kiosk
//
//  Created by Eric Meadows on 3/1/17.
//  Copyright © 2017 Calmlee. All rights reserved.
//

import UIKit
import CoreBluetooth

let paymentAddress = "https://io.calmlee.com/userExists.php"
//let paymentAddress = "https://io.calmlee.com/userExists_stripeTestMode.php"

class ViewController: UIViewController, BluetoothSerialDelegate {
    
    let defaults = UserDefaults.standard
    
    // Bluetooth Functionality
    var peripherals: [(peripheral: CBPeripheral, RSSI: Float)] = []
    var selectedPeripheral: CBPeripheral?
    var connectTimer: Timer?
    var scanTimeoutTimer: Timer?
    var sendUnlockTimer: Timer?
    let timeToRelock = 20.0
    var bluetoothStatus: String?
    
    // Regular Functionality
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    var bluetoothRx_array = [String]()
    
    let successTransition = 2.0
    let registrationTransition = 5.0
    
    let button1 = UIButton()
    let button2 = UIButton()
    let button3 = UIButton()
    let button4 = UIButton()
    let button5 = UIButton()
    let button6 = UIButton()
    let button7 = UIButton()
    let button8 = UIButton()
    let button9 = UIButton()
    let button0 = UIButton()
    let buttonDel = UIButton()
    let buttonVideo = UIButton()
    
    var swipeImage_view = UIImageView()
    var pinPadImage_view = UIImageView()
    let keurigLabel = UILabel()

    
    let payButton = UIButton()
    let subscribeButton = UIButton()
    let priceLabel = UILabel()
    let subscribeLabel = UILabel()
    let subscribeDetails = UILabel()
    
    let phoneNumberDisplay = UILabel()
    var phoneNumString: [Character] = ["(", " ", " ", " ", ")", " ", " ", " ", " ", "-", " ", " ", " ", " "]
    var phoneNumString_exact: [Character] = [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "]
    var phoneNumStringCount = 0
    
    let shapeLayer = CAShapeLayer()
    let checkMark = UILabel()
    let paymentSuccessfulLabel = UILabel()
    
    let disabledColor = UIColor(
                                red: 240/255.0,
                                green: 240/255.0,
                                blue: 240/255.0,
                                alpha: 1.0)
    let enabledColor = UIColor.black
    
    func resetPhoneNumber() {
        phoneNumString = ["(", " ", " ", " ", ")", " ", " ", " ", " ", "-", " ", " ", " ", " "]
        phoneNumString_exact = [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "]
        phoneNumStringCount = 0
        DispatchQueue.main.async {
//            self.phoneNumberDisplay.text = "Enter your phone number"
            self.phoneNumberDisplay.text = " "
        }
        self.view.setNeedsDisplay()
    }
    
    func disablePaymentButtons() {
        self.button1.isUserInteractionEnabled = false
        self.button3.isUserInteractionEnabled = false
        self.button4.isUserInteractionEnabled = false
        self.button5.isUserInteractionEnabled = false
        self.button6.isUserInteractionEnabled = false
        self.button7.isUserInteractionEnabled = false
        self.button8.isUserInteractionEnabled = false
        self.button9.isUserInteractionEnabled = false
        self.button0.isUserInteractionEnabled = false
        
        self.button1.setTitleColor(disabledColor, for: .normal)
        self.button2.setTitleColor(disabledColor, for: .normal)
        self.button3.setTitleColor(disabledColor, for: .normal)
        self.button4.setTitleColor(disabledColor, for: .normal)
        self.button5.setTitleColor(disabledColor, for: .normal)
        self.button6.setTitleColor(disabledColor, for: .normal)
        self.button7.setTitleColor(disabledColor, for: .normal)
        self.button8.setTitleColor(disabledColor, for: .normal)
        self.button9.setTitleColor(disabledColor, for: .normal)
        self.button0.setTitleColor(disabledColor, for: .normal)
        
        self.pinPadImage_view.isHidden = true
        self.swipeImage_view.isHidden = true
        self.keurigLabel.isHidden = true
        
        self.payButton.isHidden = false
        self.subscribeButton.isHidden = false
        self.subscribeLabel.isHidden = false
        self.subscribeDetails.isHidden = false
//        self.priceLabel.isHidden = false

    }
    
    func enablePaymentButtons() {
        self.button1.isUserInteractionEnabled = true
        self.button3.isUserInteractionEnabled = true
        self.button4.isUserInteractionEnabled = true
        self.button5.isUserInteractionEnabled = true
        self.button6.isUserInteractionEnabled = true
        self.button7.isUserInteractionEnabled = true
        self.button8.isUserInteractionEnabled = true
        self.button9.isUserInteractionEnabled = true
        self.button0.isUserInteractionEnabled = true
        
        self.button1.setTitleColor(enabledColor, for: .normal)
        self.button2.setTitleColor(enabledColor, for: .normal)
        self.button3.setTitleColor(enabledColor, for: .normal)
        self.button4.setTitleColor(enabledColor, for: .normal)
        self.button5.setTitleColor(enabledColor, for: .normal)
        self.button6.setTitleColor(enabledColor, for: .normal)
        self.button7.setTitleColor(enabledColor, for: .normal)
        self.button8.setTitleColor(enabledColor, for: .normal)
        self.button9.setTitleColor(enabledColor, for: .normal)
        self.button0.setTitleColor(enabledColor, for: .normal)
        
        self.pinPadImage_view.isHidden = false
        self.swipeImage_view.isHidden = false
        self.keurigLabel.isHidden = false
        
        self.payButton.isHidden = true
        self.subscribeButton.isHidden = true
        self.subscribeLabel.isHidden = true
        self.subscribeDetails.isHidden = true

//        self.priceLabel.isHidden = true
    }
    
    func successfulPayment () {
        print("Successful")
        DispatchQueue.main.async {
            self.payButton.isHidden = true
            self.subscribeButton.isHidden = true
            self.priceLabel.isHidden = true
            self.subscribeLabel.isHidden = true
            self.subscribeDetails.isHidden = true
            self.buttonVideo.setTitle("", for: .normal)
            self.payButton.setTitle("Pay Now", for: .normal)
            
            UIView.animate(withDuration: self.successTransition,
                           animations: {
                            self.shapeLayer.isHidden = false
                            self.checkMark.isHidden = false
                            self.paymentSuccessfulLabel.isHidden = false
                            
                            let animcolor = CABasicAnimation(keyPath: "fillColor")
                            animcolor.fromValue = UIColor.clear.cgColor
                            animcolor.toValue = UIColor(
                                red: 75/255.0,
                                green: 181/255.0,
                                blue: 67/255.0,
                                alpha: 1.0).cgColor
                            animcolor.duration = self.successTransition
                            animcolor.repeatCount = 0
                            animcolor.autoreverses = false
                            animcolor.isRemovedOnCompletion = false
                            animcolor.fillMode = kCAFillModeForwards
                            self.shapeLayer.add(animcolor, forKey: "fillColor")
                            
            })
            
            self.paymentSuccessfulLabel.textColor = .clear
            self.paymentSuccessfulLabel.setTextAnimation(color: UIColor(
                red: 75/255.0,
                green: 181/255.0,
                blue: 67/255.0,
                alpha: 1.0),
                                                         duration: self.successTransition)
            
            // Arduino
            // Unlock Freezer
            if (self.defaults.bool(forKey: "arduinoInstalled")) {
                self.sendUnlockMessage()
                var lockAgain = Timer.scheduledTimer(timeInterval: self.timeToRelock, target: self, selector:  Selector("sendLockMessage"), userInfo: nil, repeats: false)
            }
            
            var payAndCheck_normalAgain = Timer.scheduledTimer(timeInterval: self.successTransition, target: self, selector:  Selector("hide_greenCircle_andCheck"), userInfo: nil, repeats: false)
        }
    }
    
    func registrationRequired () {
        print("Registering")

        DispatchQueue.main.async {
            self.checkMark.text = "?"
            self.paymentSuccessfulLabel.text = "Registration SMS Sent"
            self.payButton.isHidden = true
            self.subscribeButton.isHidden = true
            self.priceLabel.isHidden = true
            self.subscribeLabel.isHidden = true
            self.subscribeDetails.isHidden = true
            self.payButton.setTitle("Pay Now", for: .normal)

            
            UIView.animate(withDuration: self.successTransition,
                           animations: {
                            self.shapeLayer.isHidden = false
                            self.checkMark.isHidden = false
                            self.paymentSuccessfulLabel.isHidden = false
                            
                            let animcolor = CABasicAnimation(keyPath: "fillColor")
                            animcolor.fromValue = UIColor.clear.cgColor
                            animcolor.toValue = UIColor(
                                red: 105/255.0,
                                green: 105/255.0,
                                blue: 105/255.0,
                                alpha: 1.0).cgColor
                            animcolor.duration = self.successTransition
                            animcolor.repeatCount = 0
                            animcolor.autoreverses = false
                            animcolor.isRemovedOnCompletion = false
                            animcolor.fillMode = kCAFillModeForwards
                            self.shapeLayer.add(animcolor, forKey: "fillColor")
                            
            })
            
            self.paymentSuccessfulLabel.textColor = .clear
            self.paymentSuccessfulLabel.setTextAnimation(color: UIColor(
                red: 105/255.0,
                green: 105/255.0,
                blue: 105/255.0,
                alpha: 1.0),
                                                         duration: self.successTransition)
            
            var timer = Timer.scheduledTimer(timeInterval: self.registrationTransition, target: self, selector:  Selector("hide_greenCircle_andCheck"), userInfo: nil, repeats: false)
            
        }
    }

    func hide_greenCircle_andCheck () {
        UIView.animateKeyframes(withDuration: 0, delay: 0, options: [], animations: {
            self.shapeLayer.isHidden = true
            self.checkMark.isHidden = true
            self.paymentSuccessfulLabel.isHidden = true
            self.priceLabel.isHidden = false
            self.resetPhoneNumber()
            self.enablePaymentButtons()
            self.paymentSuccessfulLabel.text = "Payment Successful"
            self.checkMark.text = "✓"
        }) { (finished) in
            if finished {
                print("Done")
            }
        }
    }
    
    func numpadPressed(sender: UIButton) {
//        print(sender.titleLabel?.text ?? "Oops")
        if sender.titleLabel?.text != "x" {
            if phoneNumStringCount < 10 {
                phoneNumString_exact[phoneNumStringCount] = Character((sender.titleLabel?.text)!)
                phoneNumStringCount += 1
                if phoneNumStringCount <= 3 {
                    phoneNumString[phoneNumStringCount] = Character((sender.titleLabel?.text)!)
                }
                else if phoneNumStringCount <= 6 {
                    phoneNumString[phoneNumStringCount+2] = Character((sender.titleLabel?.text)!)
                }
                else if phoneNumStringCount <= 10 {
                    phoneNumString[phoneNumStringCount+3] = Character((sender.titleLabel?.text)!)
                }
            }
            phoneNumberDisplay.text = String(phoneNumString)
        }
        else {
            if phoneNumStringCount > 0 {
                if phoneNumStringCount <= 3 {
                    phoneNumString[phoneNumStringCount] = " "
                }
                else if phoneNumStringCount <= 6 {
                    phoneNumString[phoneNumStringCount+2] = " "
                }
                else if phoneNumStringCount <= 10 {
                    phoneNumString[phoneNumStringCount+3] = " "
                }
                phoneNumStringCount -= 1
                phoneNumString_exact[phoneNumStringCount] = " "
                phoneNumberDisplay.text = String(phoneNumString)
            }
            if phoneNumStringCount == 0 {
                phoneNumberDisplay.text = ""
            }
        }
        if phoneNumStringCount == 10 {
            self.disablePaymentButtons()
            if (String(phoneNumString_exact) == "9377761657") {
                buttonVideo.setTitle("Setup", for: .normal)
            }
        }
        else {
            self.enablePaymentButtons()
            buttonVideo.setTitle("", for: .normal)
        }
//        print(String(phoneNumString))
//        print(phoneNumStringCount)
//        print("")
    }
    let screenSize: CGRect = UIScreen.main.bounds
    var initialLoad = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Software revision
//        [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
        let nsObject: AnyObject? = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as AnyObject
        print(nsObject as! String)
        
        // Arduino
        // Load based upon setup value
        defaults.set(true, forKey: "arduinoInstalled")
        defaults.set("Sentient", forKey: "company")
        defaults.set("1.1", forKey: "version")
        
        // Buttons
        let num_w = self.screenSize.width/8
        let num_h = self.screenSize.height/8
        
        // c#x
        let c1x = self.screenSize.width*(1/2 + 1/16)
        let c2x = self.screenSize.width*(1/2 + 1/16 + 1/8)
        let c3x = self.screenSize.width*(1/2 + 1/16 + 2/8)
        
        // r#y
        let r1y = self.screenSize.height*(1/4 + 1/8)
        let r2y = self.screenSize.height*(1/4 + 2/8)
        let r3y = self.screenSize.height*(1/4 + 3/8)
        let r4y = self.screenSize.height*(1/4 + 4/8)
        //        let r5y = self.screenSize.height*(1/8 + 5/8)
        
//        let snackblendLogo = UILabel()
//        snackblendLogo.frame = CGRect(x: 0,
//                                      y: self.screenSize.height/12,
//                                      width: self.screenSize.width,
//                                      height: self.screenSize.width/4)
//        snackblendLogo.textAlignment = NSTextAlignment.center
//        snackblendLogo.font = UIFont(name: "Grand Hotel", size: snackblendLogo.frame.height)
//        snackblendLogo.textColor = UIColor.white
//        snackblendLogo.text = "SnackBlend"
//        view.addSubview(snackblendLogo)
//        
                let imageName = "OriginLogo.png"
//        let imageName = "snackblendLogo.png"
        let image = UIImage(named: imageName)
        let imageView = UIImageView(image: image!)
//        imageView.frame = CGRect(x: 0, y: self.screenSize.height*(1/8),
//                                 width: self.screenSize.width / 2,
//                                 height: self.screenSize.height*(1/6))
        imageView.frame = CGRect(x: self.screenSize.width / 16, y: self.screenSize.height*(1/8),
                                 width: self.screenSize.width * 3 / 8,
                                 height: self.screenSize.height*(1/6))
        imageView.contentMode = .scaleAspectFit
        view.addSubview(imageView)
        
        // Swipe and PIN Pad icons
        let swipeImage = UIImage(named: "creditCardSwipe.png")
//        let swipeImage_view = UIImageView(image: swipeImage)
        swipeImage_view.image = swipeImage
        swipeImage_view.frame = CGRect(x: self.screenSize.width * (1/3 - 1/32),
                                       y: (r2y + r3y) / 2,
                                       width: self.screenSize.width / 16,
                                       height: self.screenSize.width / 16)
        swipeImage_view.contentMode = .scaleAspectFit
        view.addSubview(swipeImage_view)
        
        let pinPadImage = UIImage(named: "pinPadEntry.png")
//        let pinPadImage_view = UIImageView(image: pinPadImage)
        pinPadImage_view.image = pinPadImage
        pinPadImage_view.frame = CGRect(x: self.screenSize.width * (1/6 - 1/32),
                                        y: (r2y + r3y) / 2,
                                        width: self.screenSize.width / 16,
                                        height: self.screenSize.width / 16)
        pinPadImage_view.contentMode = .scaleAspectFit
        view.addSubview(pinPadImage_view)
        
        // Keurig for Health Smoothies - Label
//        let keurigLabel = UILabel()
//        keurigLabel.frame = CGRect(x: self.screenSize.width / 16,
//                                   y: imageView.frame.maxY + self.screenSize.height / 48,
//                                   width: self.screenSize.width * 3 / 8,
//                                   height: self.screenSize.height*(1/6))
        keurigLabel.frame = CGRect(x: self.screenSize.width / 24,
                                   y: r4y,
                                   width: self.screenSize.width * 5 / 12,
                                   height: self.screenSize.height / 6)
        keurigLabel.textAlignment = NSTextAlignment.center
        keurigLabel.baselineAdjustment = UIBaselineAdjustment.alignCenters
        keurigLabel.font = UIFont(name: "Arial", size: self.screenSize.height*(7/170))
        keurigLabel.numberOfLines = 0
        keurigLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
//        keurigLabel.text = "Enter phone number or swipe credit card to begin"
        let formattedString = NSMutableAttributedString()
        
        formattedString.append(NSAttributedString(string: "Enter "))
        
        let attrs:[String:AnyObject] = [NSFontAttributeName : UIFont(name: "AvenirNext-Bold", size: self.screenSize.height*(7/170))!]
        var text = "Phone Number "
        formattedString.append(NSMutableAttributedString(string:"\(text)", attributes:attrs))
        
        formattedString.append(NSAttributedString(string: "\nor \n"))
        
        text = "Swipe Credit Card" // "Swipe Credit Card "
        formattedString.append(NSMutableAttributedString(string:"\(text)", attributes:attrs))
        
//        formattedString.append(NSAttributedString(string: "\nto begin"))
        
        keurigLabel.attributedText = formattedString
        view.addSubview(keurigLabel)

        
//        priceLabel.frame = CGRect(x: self.screenSize.width / 8,
//                                 y: r3y - self.screenSize.height / 16,
//                                 width: self.screenSize.width / 4,
//                                 height: self.screenSize.height / 8)
        priceLabel.frame = CGRect(x: self.screenSize.width / 8,
                                  y: r1y - self.screenSize.height / 16,//(imageView.frame.maxY + (r2y + r3y) / 2) / 2 - self.screenSize.height / 5,
                                  width: self.screenSize.width / 4,
                                  height: self.screenSize.height / 5)
        priceLabel.text = "$5.99"
        priceLabel.font = UIFont.boldSystemFont(ofSize: priceLabel.frame.height / 2)
        priceLabel.textAlignment = .center
        priceLabel.textColor = .black
        priceLabel.isHidden = false
        view.addSubview(self.priceLabel)
        
        subscribeLabel.frame = CGRect(x: self.screenSize.width / 8,
                                      y: r3y - self.screenSize.height / 16,
                                      width: self.screenSize.width / 4,
                                      height: self.screenSize.height / 5)
        subscribeLabel.text = "$2.99"
        subscribeLabel.font = UIFont.boldSystemFont(ofSize: priceLabel.frame.height / 2)
        subscribeLabel.textAlignment = .center
        subscribeLabel.textColor = .black
        subscribeLabel.isHidden = true
        view.addSubview(self.subscribeLabel)
        
        subscribeDetails.frame = CGRect(x: self.screenSize.width / 24,
                                        y: r4y,
                                        width: self.screenSize.width * 5 / 12,
                                        height: self.screenSize.height / 6)
        subscribeDetails.textAlignment = NSTextAlignment.center
        subscribeDetails.baselineAdjustment = UIBaselineAdjustment.alignCenters
        subscribeDetails.font = UIFont(name: "Arial", size: self.screenSize.height*(7/170))
        subscribeDetails.numberOfLines = 0
        subscribeDetails.lineBreakMode = NSLineBreakMode.byWordWrapping
        subscribeDetails.text = "3 Smoothies / Week"
        subscribeDetails.isHidden = true
        view.addSubview(subscribeDetails)
        
        
        payButton.frame = CGRect(x: self.screenSize.width / 8,
                                 y: r2y - self.screenSize.height / 32,// r3y - self.screenSize.height / 16,
            width: self.screenSize.width / 4,
            height: self.screenSize.height / 16)
        payButton.setTitle("Pay Now", for: .normal)
        payButton.setTitleColor(.black, for: .normal)
        payButton.setTitleColor(UIColor(red: 75/255.0,
                                        green: 181/255.0,
                                        blue: 67/255.0,
                                        alpha: 1.0),
                                for: .highlighted)
        payButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: payButton.frame.height / 2)
        payButton.backgroundColor = UIColor.white
        payButton.layer.borderColor = UIColor.black.cgColor
        payButton.layer.borderWidth = 6
        payButton.layer.cornerRadius = payButton.frame.height / 4//0.5 * button1.bounds.size.width
        payButton.clipsToBounds = true
        payButton.isHidden = true
        payButton.addTarget(self, action: #selector(processPayment), for: .touchUpInside)
        view.addSubview(self.payButton)
        
        subscribeButton.frame = CGRect(x: payButton.frame.minX,
                                       y: r4y - self.screenSize.height / 32,
                                       width: payButton.frame.width,
                                       height: payButton.frame.height)
        subscribeButton.setTitle("Subscribe", for: .normal)
        subscribeButton.setTitleColor(.black, for: .normal)
        subscribeButton.setTitleColor(UIColor(red: 75/255.0,
                                              green: 181/255.0,
                                              blue: 67/255.0,
                                              alpha: 1.0),
                                      for: .highlighted)
        subscribeButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: payButton.frame.height / 2)
        subscribeButton.backgroundColor = UIColor.white
        subscribeButton.layer.borderColor = UIColor.black.cgColor
        subscribeButton.layer.borderWidth = 6
        subscribeButton.layer.cornerRadius = payButton.frame.height / 4//0.5 * button1.bounds.size.width
        subscribeButton.clipsToBounds = true
        subscribeButton.isHidden = true
        subscribeButton.addTarget(self, action: #selector(processSubscription), for: .touchUpInside)
        view.addSubview(self.subscribeButton)
        
        
        // Payment Successful - Label
        let circle_x = self.screenSize.width / 4
        let circle_r = self.screenSize.height / 16
        let circle_y = self.screenSize.height * 2 / 3 - circle_r
        
        let circlePath = UIBezierPath(
            arcCenter: CGPoint(x: circle_x,
                               y: circle_y),
            radius: circle_r,
            startAngle: CGFloat(0), endAngle:CGFloat(M_PI * 2), clockwise: true)
        self.shapeLayer.path = circlePath.cgPath

        self.shapeLayer.fillColor = UIColor.clear.cgColor
//        self.shapeLayer.fillColor = UIColor(
//                                        red: 75/255.0,
//                                        green: 181/255.0,
//                                        blue: 67/255.0,
//                                        alpha: 1.0).cgColor
        self.shapeLayer.strokeColor = self.shapeLayer.fillColor
        self.shapeLayer.lineWidth = 3.0
        view.layer.addSublayer(self.shapeLayer)
        
        // Check Mark icon
        self.checkMark.frame = CGRect(x: circle_x - circle_r,
                                      y: circle_y - circle_r,
                                      width: circle_r * 2,
                                      height: circle_r * 2)
        self.checkMark.textAlignment = NSTextAlignment.center
        self.checkMark.baselineAdjustment = UIBaselineAdjustment.alignCenters
        self.checkMark.font = UIFont(name: "Arial", size: self.screenSize.height*(1/12))
        self.checkMark.textColor = UIColor.white
        self.checkMark.numberOfLines = 0
        self.checkMark.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.checkMark.text = "✓"
        view.addSubview(self.checkMark)
        
        // Payment Successful - Label
        self.paymentSuccessfulLabel.frame = CGRect(x: self.screenSize.width / 16,
                                                   y: self.screenSize.height*(3/4 - 1/12),
                                                   width: self.screenSize.width * 3 / 8,
                                                   height: self.screenSize.height*(1/6))
        self.paymentSuccessfulLabel.textAlignment = NSTextAlignment.center
        self.paymentSuccessfulLabel.baselineAdjustment = UIBaselineAdjustment.alignCenters
        self.paymentSuccessfulLabel.font = UIFont(name: "Arial", size: self.screenSize.height*(7/160))
        self.paymentSuccessfulLabel.numberOfLines = 0
        self.paymentSuccessfulLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.paymentSuccessfulLabel.text = "Payment Successful"
        view.addSubview(self.paymentSuccessfulLabel)
        
        // Hide until successful payment
        if (!initialLoad) {
            self.shapeLayer.isHidden = true
            self.checkMark.isHidden = true
            self.paymentSuccessfulLabel.isHidden = true
        }

        
        // Phone Number Display
        phoneNumberDisplay.frame = CGRect(x: self.screenSize.width*(1/2 + 1/16),
                                          y: imageView.frame.minY,
                                          width: self.screenSize.width*(3 / 8),
                                          height: self.screenSize.height*(1/4))
        phoneNumberDisplay.textAlignment = NSTextAlignment.center
        phoneNumberDisplay.baselineAdjustment = UIBaselineAdjustment.alignCenters
        phoneNumberDisplay.font = UIFont(name: "Arial", size: self.screenSize.height*(7/160))
        phoneNumberDisplay.numberOfLines = 0
        phoneNumberDisplay.frame.size.width = self.screenSize.width*(3 / 8)
        phoneNumberDisplay.lineBreakMode = NSLineBreakMode.byWordWrapping
//        phoneNumberDisplay.text = "Enter your phone number to pay"
        phoneNumberDisplay.text = " "
        view.addSubview(phoneNumberDisplay)
        
        // border
        let border_c = UIColor(red: 203/255.0, green: 203/255.0, blue: 203/255.0, alpha: 1.0).cgColor
//        cbcbcb
        let border_w = CGFloat(3.0)
        
        
        // Button Borders
        // Add a bottom border.
        func addBottomBorder(button: UIButton) {
            let bottomBorder = CALayer()
            bottomBorder.frame = CGRect(x: 0.0,
                                        y: (button.frame.size.height-border_w/2),
                                        width: button.frame.size.width,
                                        height: border_w)
            bottomBorder.backgroundColor = border_c
            button.layer.addSublayer(bottomBorder)
        }
        // Add a top border.
        func addTopBorder(button: UIButton) {
            let bottomBorder = CALayer()
            bottomBorder.frame = CGRect(x: 0.0,
                                        y: -border_w/2,
                                        width: button.frame.size.width,
                                        height: border_w)
            bottomBorder.backgroundColor = border_c
            button.layer.addSublayer(bottomBorder)
        }
        // Add a left border.
        func addLeftBorder(button: UIButton) {
            let bottomBorder = CALayer()
            bottomBorder.frame = CGRect(x: -border_w/2,
                                        y: 0.0,
                                        width: border_w,
                                        height: button.frame.size.width)
            bottomBorder.backgroundColor = border_c
            button.layer.addSublayer(bottomBorder)
        }
        // Add a right border.
        func addRightBorder(button: UIButton) {
            let bottomBorder = CALayer()
            bottomBorder.frame = CGRect(x: button.frame.size.width-border_w/2,
                                        y: 0.0,
                                        width: border_w,
                                        height: button.frame.size.width)
            bottomBorder.backgroundColor = border_c
            button.layer.addSublayer(bottomBorder)
        }
        
        // ROW 1
        button1.frame = CGRect(x: c1x,
                               y: r1y,
                               width: num_w,
                               height: num_h)
        button1.setTitle("1", for: .normal)
        button1.setTitleColor(.black, for: .normal)
        button1.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button1.backgroundColor = UIColor.white
        button1.layer.cornerRadius = 0//0.5 * button1.bounds.size.width
        button1.clipsToBounds = true
        button1.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button1)
        addRightBorder(button: button1)
        view.addSubview(button1)
        
        button2.frame = CGRect(x: c2x,
                               y: r1y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button2.setTitle("2", for: .normal)
        button2.setTitleColor(.black, for: .normal)
        button2.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button2.backgroundColor = UIColor.white
        button2.layer.cornerRadius = button1.layer.cornerRadius
        button2.clipsToBounds = true
        button2.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button2)
        addRightBorder(button: button2)
        addLeftBorder(button: button2)
        view.addSubview(button2)
        
        button3.frame = CGRect(x: c3x,
                               y: r1y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button3.setTitle("3", for: .normal)
        button3.setTitleColor(.black, for: .normal)
        button3.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button3.backgroundColor = UIColor.white
        button3.layer.cornerRadius = button1.layer.cornerRadius
        button3.clipsToBounds = true
        button3.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button3)
        addLeftBorder(button: button3)
        view.addSubview(button3)
        
        // ROW 2
        button4.frame = CGRect(x: c1x,
                               y: r2y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button4.setTitle("4", for: .normal)
        button4.setTitleColor(.black, for: .normal)
        button4.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button4.backgroundColor = UIColor.white
        button4.layer.cornerRadius = button1.layer.cornerRadius
        button4.clipsToBounds = true
        button4.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button4)
        addRightBorder(button: button4)
        addTopBorder(button: button4)
        view.addSubview(button4)
        
        button5.frame = CGRect(x: c2x,
                               y: r2y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button5.setTitle("5", for: .normal)
        button5.setTitleColor(.black, for: .normal)
        button5.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button5.backgroundColor = UIColor.white
        button5.layer.cornerRadius = button1.layer.cornerRadius
        button5.clipsToBounds = true
        button5.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button5)
        addRightBorder(button: button5)
        addLeftBorder(button: button5)
        addTopBorder(button: button5)
        view.addSubview(button5)
        
        button6.frame = CGRect(x: c3x,
                               y: r2y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button6.setTitle("6", for: .normal)
        button6.setTitleColor(.black, for: .normal)
        button6.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button6.backgroundColor = UIColor.white
        button6.layer.cornerRadius = button1.layer.cornerRadius
        button6.clipsToBounds = true
        button6.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button6)
        addLeftBorder(button: button6)
        addTopBorder(button: button6)
        view.addSubview(button6)
        
        // ROW3
        button7.frame = CGRect(x: c1x,
                               y: r3y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button7.setTitle("7", for: .normal)
        button7.setTitleColor(.black, for: .normal)
        button7.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button7.backgroundColor = UIColor.white
        button7.layer.cornerRadius = button1.layer.cornerRadius
        button7.clipsToBounds = true
        button7.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button7)
        addRightBorder(button: button7)
        addTopBorder(button: button7)
        view.addSubview(button7)
        
        button8.frame = CGRect(x: c2x,
                               y: r3y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button8.setTitle("8", for: .normal)
        button8.setTitleColor(.black, for: .normal)
        button8.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button8.backgroundColor = UIColor.white
        button8.layer.cornerRadius = button1.layer.cornerRadius
        button8.clipsToBounds = true
        button8.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button8)
        addRightBorder(button: button8)
        addLeftBorder(button: button8)
        addTopBorder(button: button8)
        view.addSubview(button8)
        
        button9.frame = CGRect(x: c3x,
                               y: r3y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button9.setTitle("9", for: .normal)
        button9.setTitleColor(.black, for: .normal)
        button9.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button9.backgroundColor = UIColor.white
        button9.layer.cornerRadius = button1.layer.cornerRadius
        button9.clipsToBounds = true
        button9.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addBottomBorder(button: button9)
        addLeftBorder(button: button9)
        addTopBorder(button: button9)
        view.addSubview(button9)
        
        // ROW 4
        buttonVideo.frame = CGRect(x: c1x,
                                   y: r4y,
                                   width: button1.frame.width,
                                   height: button1.frame.height)
        buttonVideo.setTitle("", for: .normal)
        buttonVideo.setTitleColor(.black, for: .normal)
        buttonVideo.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height/4)
        buttonVideo.backgroundColor = UIColor.white
        buttonVideo.layer.cornerRadius = button1.layer.cornerRadius
        buttonVideo.clipsToBounds = true
        buttonVideo.addTarget(self, action: #selector(gotoSetup), for: .touchUpInside)
        addRightBorder(button: buttonVideo)
        addTopBorder(button: buttonVideo)
        view.addSubview(buttonVideo)
        
        button0.frame = CGRect(x: c2x,
                               y: r4y,
                               width: button1.frame.width,
                               height: button1.frame.height)
        button0.setTitle("0", for: .normal)
        button0.setTitleColor(.black, for: .normal)
        button0.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        button0.backgroundColor = UIColor.white
        button0.layer.cornerRadius = button1.layer.cornerRadius
        button0.clipsToBounds = true
        button0.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addRightBorder(button: button0)
        addLeftBorder(button: button0)
        addTopBorder(button: button0)
        view.addSubview(button0)
        
        buttonDel.frame = CGRect(x: c3x,
                                 y: r4y,
                                 width: button1.frame.width,
                                 height: button1.frame.height)
        buttonDel.setTitle("x", for: .normal)
        buttonDel.setTitleColor(.clear, for: .normal)
        buttonDel.layer.cornerRadius = button1.layer.cornerRadius
        buttonDel.setImage(#imageLiteral(resourceName: "delButton_image"), for: .normal)
        buttonDel.clipsToBounds = true
        buttonDel.imageEdgeInsets = UIEdgeInsetsMake(
                                            button1.frame.width*0,
                                            button1.frame.width/8,
                                            button1.frame.width*0,
                                            button1.frame.width/8)
        buttonDel.contentMode = .scaleAspectFit
        buttonDel.titleLabel?.font = UIFont.boldSystemFont(ofSize: button1.frame.height*2/3)
        buttonDel.backgroundColor = UIColor.white
        buttonDel.addTarget(self, action: #selector(numpadPressed), for: .touchUpInside)
        addLeftBorder(button: buttonDel)
        addTopBorder(button: buttonDel)
        view.addSubview(buttonDel)

        // Do any additional setup after loading the view, typically from a nib.
        self.initialLoad = true
        
        // Bluetooth setup
        serial = BluetoothSerial(delegate: self)
        let when = DispatchTime.now() + 0.1 // change 2 to desired number of seconds
        DispatchQueue.main.asyncAfter(deadline: when) {
            // Your code with delay
        }
        
        // Arduino
        if (defaults.bool(forKey: "arduinoInstalled")) {
            connectTimer = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(ViewController.scanForPeriph), userInfo: nil, repeats: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Arduino
    // MARK: - Bluetooth Connection Functions
    func scanForPeriph() {
        serial.startScan()
        scanTimeoutTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(ViewController.scanTimeOut), userInfo: nil, repeats: false)
    }
    
    func scanTimeOut() {
        serial.stopScan()
        print("timedOut")
    }
    
    func connectToDefaultPeripheral() {
        let mainPeripheral = peripherals[0].peripheral
        serial.connectToPeripheral(mainPeripheral)
        print("-----")
        print(peripherals)
        print(mainPeripheral.name!)
        print(mainPeripheral.name!.characters.last!)
        print("-----")
        connectTimer?.invalidate()
        connectTimer = nil
        scanTimeoutTimer?.invalidate()
        scanTimeoutTimer = nil
        
//        sendUnlockTimer = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(ViewController.sendUnlockMessage), userInfo: nil, repeats: true)
    }
    
    func sendUnlockMessage() {
//        serial.sendMessageToDevice("u")
        serial.sendMessageToDevice("UNLOCK\n")
    }
    
    func sendLockMessage() {
//        serial.sendMessageToDevice("l")
        serial.sendMessageToDevice("LOCK\n")
//        if (bluetoothStatus == "BOTH") {
//            serial.sendMessageToDevice("LOCK\n")
//        }
//        else {
//            alarm noise
//        }
    }
    
    //MARK: BluetoothSerialDelegate
    
    func serialDidReceiveString(_ message: String) {
        print(message)
        bluetoothStatus = message
        
        if (message.range(of:"<CCINFO>") != nil) {
            bluetoothRx_array.append(message)
        }
        else if (message.range(of:"</CCINFO>") != nil) {
            bluetoothRx_array.append(message)
            // Epona
            // Epona
            // Epona
            // Epona
            // Epona
            // Epona
            // Epona
            // Epona
        }
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
    }
    
    func serialDidDiscoverPeripheral(_ peripheral: CBPeripheral, RSSI: NSNumber?) {
        // check whether it is a duplicate
        for exisiting in peripherals {
            if exisiting.peripheral.identifier == peripheral.identifier { return }
        }
        
        let theRSSI = RSSI?.floatValue ?? 0.0
        peripherals.append(peripheral: peripheral, RSSI: theRSSI)
        peripherals.sort { $0.RSSI < $1.RSSI }
        connectToDefaultPeripheral()
    }
    
    func serialDidFailToConnect(_ peripheral: CBPeripheral, error: NSError?) {
    }
    
    func serialIsReady(_ peripheral: CBPeripheral) {
    }
    
    func serialDidChangeState() {
    }
    
    // MARK: - Pre-BT functions
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    func processSubscription() {
        print("Process subscription")
    }
    
    func processPayment() {
        // Process Payment - PPMT
        self.payButton.backgroundColor = .black
        self.payButton.setTitle("Wait", for: .normal)
        self.payButton.setTitleColor(.white, for: .normal)
        
        // Add one parameter
        let phoneString = "?phoneNumber=" + String(phoneNumString_exact)
        let versionString = "&version=" + defaults.string(forKey: "version")!
        let companyString = "&companyName=" + defaults.string(forKey: "company")!
        let urlWithParams = paymentAddress + phoneString + companyString + versionString
        print(urlWithParams)
        
        // Create NSURL Object
        let myUrl = NSURL(string: urlWithParams);
        
        // Creaste URL Request
        let request = NSMutableURLRequest(url:myUrl! as URL);
        
        // Set request HTTP method to GET. It could be POST as well
        request.httpMethod = "GET"
        
        /* TESTING HERE */
        
        // Excute HTTP Request
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            // Check for error
            if error != nil
            {
                print("error=\(error)")
                return
            }
            
            // Print out response string
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            //             print("responseString = \(responseString)")
            let chargeResponse = String(describing: responseString!).components(separatedBy: ",")
//            print(chargeResponse)
            
            if (chargeResponse[0] == "Customer not created") {
                self.registrationRequired()
            }
            
            // Convert server json response to NSDictionary
            do {
                if let convertedJsonIntoDict = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary {
                    // Print out dictionary
//                    print(data!)
//                    print(convertedJsonIntoDict)
                    if (String(describing: convertedJsonIntoDict["status"]!) == "succeeded") {
                        self.successfulPayment()
                    }
                    
                    // Get value by key
                    //                    let firstNameValue = convertedJsonIntoDict["userName"] as? String
                    //                    print(firstNameValue!)
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
        
        task.resume()
        
        /* FINISHED TESTING */
    }
    
//    func gotoVideo_transition(sender: UIButton) {
//        self.performSegue(withIdentifier: "goto_videoTracking", sender: Any?.self)
//    }
    
    func gotoSetup (sender: UIButton) {
        if (sender.title(for: .normal) == "Setup") {
            self.performSegue(withIdentifier: "gotoSetup", sender: Any?.self)
        }
    }
}



//        for family: String in UIFont.familyNames
//        {
//            print("\(family)")
//            for names: String in UIFont.fontNames(forFamilyName: family)
//            {
//                print("== \(names)")
//            }
//        }

extension String {
    
    subscript (r: CountableClosedRange<Int>) -> String {
        get {
            let startIndex =  self.index(self.startIndex, offsetBy: r.lowerBound)
            let endIndex = self.index(startIndex, offsetBy: r.upperBound - r.lowerBound)
            return self[startIndex...endIndex]
        }
    }
}

extension UILabel {
    /**
     Set Text With animation
     
     - parameter text:     String?
     - parameter duration: NSTimeInterval?
     */
    public func setTextAnimation(text: String? = nil, color: UIColor? = nil, duration: TimeInterval?, completion:(()->())? = nil) {
        UIView.transition(with: self, duration: duration ?? 0.3, options: .transitionCrossDissolve, animations: { () -> Void in
            self.text = text ?? self.text
            self.textColor = color ?? self.textColor
        }) { (finish) in
            if finish { completion?() }
        }
    }
}

extension NSMutableAttributedString {
    func bold(_ text:String) -> NSMutableAttributedString {
        let attrs:[String:AnyObject] = [NSFontAttributeName : UIFont(name: "AvenirNext-Medium", size: 12)!]
        let boldString = NSMutableAttributedString(string:"\(text)", attributes:attrs)
        self.append(boldString)
        return self
    }
    
    func normal(_ text:String)->NSMutableAttributedString {
        let normal =  NSAttributedString(string: text)
        self.append(normal)
        return self
    }
}
