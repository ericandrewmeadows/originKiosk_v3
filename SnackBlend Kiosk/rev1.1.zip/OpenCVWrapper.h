//
//  OpenCVWrapper.h
//  SnackBlend Kiosk
//
//  Created by Eric Meadows on 3/8/17.
//  Copyright © 2017 Calmlee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OpenCVWrapper : NSObject
- (void)isThisWorking;
@end
