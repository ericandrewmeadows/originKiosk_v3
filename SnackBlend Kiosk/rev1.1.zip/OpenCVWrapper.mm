//
//  OpenCVWrapper.m
//  SnackBlend Kiosk
//
//  Created by Eric Meadows on 3/8/17.
//  Copyright © 2017 Calmlee. All rights reserved.
//

#import "OpenCVWrapper.h"
//#import <opencv2/opencv.hpp>

using namespace std;

//@implementation OpenCVWrapper
//- (void) isThisWorking {
//    cout << "Hey" << endl;
//}
//@end
